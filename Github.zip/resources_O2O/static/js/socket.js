var stompClient = null;

function connect(func) {
    var socket = new SockJS('/connect');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);
        stompClient.subscribe('/topic/notification', function (message) {
            func(JSON.parse(message.body).content);
        });
    });
}
