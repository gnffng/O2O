window.onload = function () {
    if (window.Notification) {
        Notification.requestPermission();
    }
}

function notify(id) {
    if (Notification.permission !== 'granted') {
        alert('notification is disabled');
    }
    else {
        var notification = new Notification('주문 알림', {
            icon: 'http://cdn.sstatic.net/stackexchange/img/logos/so/so-icon.png',
            body: '주문이 들어왔습니다.',
            requireInteraction: true
        });

        notification.onclick = function () {
            window.open('/admin/order/'+id+'/');
        };
    }
}
